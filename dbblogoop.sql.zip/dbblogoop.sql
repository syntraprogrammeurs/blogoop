-- phpMyAdmin SQL Dump
-- version 4.7.9
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Gegenereerd op: 21 feb 2019 om 10:00
-- Serverversie: 5.7.21
-- PHP-versie: 7.2.4

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbblogoop`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `comments`
--

DROP TABLE IF EXISTS `comments`;
CREATE TABLE IF NOT EXISTS `comments` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `photo_id` int(11) NOT NULL,
  `author` varchar(255) NOT NULL,
  `body` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=8 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `comments`
--

INSERT INTO `comments` (`id`, `photo_id`, `author`, `body`) VALUES
(1, 1, 'Tom', 'commentaar 1'),
(2, 1, 'Tim', 'test'),
(3, 1, 'ok', 'test'),
(4, 1, 'Ruben', 'ruben zijn commentaar');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `photos`
--

DROP TABLE IF EXISTS `photos`;
CREATE TABLE IF NOT EXISTS `photos` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `caption` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `filename` varchar(255) NOT NULL,
  `alternate_text` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `size` int(11) NOT NULL,
  `created_at` timestamp NOT NULL,
  `updated_at` timestamp NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `photos`
--

INSERT INTO `photos` (`id`, `title`, `caption`, `description`, `filename`, `alternate_text`, `type`, `size`, `created_at`, `updated_at`) VALUES
(1, 'Photo Belgiums', 'test', '<p>lorem ipsumlorem i<strong>psumlorem</strong> ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem ipsumlorem<strong> ipsumlorem ipsum</strong></p>', '', 'test', '', 35, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(2, 'france', '', 'france lorem ipsum', '', '', '', 40, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(5, 'test', '', '', '16 maart.png', '', 'image/png', 4101, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(6, 'fotofrankrijk', '', '', 'syntrawestopendeur2.png', '', 'image/png', 93759, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(7, 'dsdf', '', '', 'bestellingtarief_Duitsland.PNG', '', 'image/png', 10585, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(8, 'dsfsdfsdqf', '', '', 'jijkomtochook.png', '', 'image/png', 65847, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(9, 'erezr', '', '', '16 maart.png', '', 'image/png', 4101, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(10, 'test', '', '', 'kalender.png', '', 'image/png', 73965, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(11, 'test', '', '', 'kalender.png', '', 'image/png', 73965, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(12, 'dfdsd', '', '', 'aanwezigheid.PNG', '', 'image/png', 39986, '0000-00-00 00:00:00', '0000-00-00 00:00:00'),
(13, 'kip', '', '', 'kip-16130.jpg', '', 'image/jpeg', 49846, '0000-00-00 00:00:00', '0000-00-00 00:00:00');

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` int(11) UNSIGNED NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(255) NOT NULL,
  `last_name` varchar(255) NOT NULL,
  `user_image` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=47 DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `first_name`, `last_name`, `user_image`) VALUES
(1, 'Tom', '123456', 'Piet', 'WILLIAM', ''),
(32, 'Neville', '123', 'Neville', 'Verleye', ''),
(4, 'Marieke', '123', 'Marieke', 'Decabooter', ''),
(5, 'Brent', '$1$lNw5UXwo$lUTPDUL.AT0ya2a.v.3UJ0', 'Brent', 'Vanhooren', ''),
(6, 'Brent', '202cb962ac59075b964b07152d234b70', 'Brent', 'Vanhooren', ''),
(7, 'Brent', '202cb962ac59075b964b07152d234b70', 'Brent', 'Vanhooren', ''),
(8, 'Brent', '202cb962ac59075b964b07152d234b70', 'Brent', 'Vanhooren', ''),
(9, 'Brent', '123', 'Brent', 'Vanhooren', ''),
(34, 'Neville', '123', 'Neville', 'Verleye', ''),
(33, 'Neville', '123', 'Neville', 'Verleye', ''),
(31, 'Neville', '123', 'Neville', 'Verleye', ''),
(30, 'Neville', '123', 'Neville', 'Verleye', ''),
(29, 'Neville', '123', 'Neville', 'Verleye', ''),
(28, 'Neville', '123', 'Neville', 'Verleye', ''),
(27, 'Neville', '123', 'Neville', 'Verleye', ''),
(26, 'Neville', '123', 'Neville', 'Verleye', ''),
(25, 'Neville', '123', 'Neville', 'Verleye', ''),
(24, 'Neville', '123', 'Neville', 'Verleye', ''),
(23, 'Neville', '123', 'Neville', 'Verleye', ''),
(22, 'Neville', '3c9909afec25354d551dae21590bb26e38d53f2173b8d3dc3eee4c047e7ab1c1eb8b85103e3be7ba613b31bb5c9c36214dc9f14a42fd7a2fdb84856bca5c44c2', 'Neville', 'Verleye', ''),
(35, 'Neville', '123', 'Neville', 'Verleye', ''),
(36, 'test', '123', 'test', 'test', ''),
(37, 'test', '123', 'test', 'test', ''),
(38, 'test', '123', 'test', 'test', ''),
(39, 'test', '123', 'test', 'test', ''),
(40, 'test', '123', 'test', 'test', ''),
(41, 'test', '123', 'test', 'test', ''),
(42, 'test', '123', 'test', 'test', ''),
(43, 'test', '123', 'test', 'test', 'avatar4.jpg'),
(44, 'test', '123', 'test', 'test', 'avatar3.jpg'),
(45, 'dfsdfqsdfsd', 'qsdfdfqsdffd', 'dsqfqsd', 'qsdqsdfqsdfqsdf', 'avatar3.jpg'),
(46, 'avatar4', 'avatar3', 'avatar4', 'avatar4', 'avatar4.jpg');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
